// 排班管理系统 - 本地存储版本

// 全局变量
let currentYear = new Date().getFullYear();
let currentMonth = new Date().getMonth() + 1;
let attendanceEmployees = [];
let attendanceData = {};
let substituteData = {};
let currentContextCell = null;

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM已加载，开始初始化...');
    
    try {
        // 初始化年月选择器
        initializeDateSelectors();
        
        // 加载考勤员工
        loadAttendanceEmployees();
        
        // 绑定全局事件
        bindGlobalEvents();
        
        console.log('排班管理系统已加载 - 本地存储版本');
        
    } catch (error) {
        console.error('系统初始化失败:', error);
    }
});

// 确保所有函数定义完成后再显示默认页面
window.addEventListener('load', function() {
    try {
        showPage('projects');
        console.log('默认页面已显示');
    } catch (error) {
        console.error('显示默认页面失败:', error);
    }
});

// 绑定全局事件
function bindGlobalEvents() {
    // 点击页面其他地方隐藏右键菜单
    document.addEventListener('click', function(e) {
        const contextMenu = document.getElementById('contextMenu');
        if (contextMenu && !contextMenu.contains(e.target)) {
            hideContextMenu();
        }
    });
    
    // ESC键隐藏右键菜单
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            hideContextMenu();
        }
    });
}

// 初始化年月选择器
function initializeDateSelectors() {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    
    // 项目管理年月选择器
    const projectYearSelect = document.getElementById('project-year');
    const projectMonthSelect = document.getElementById('project-month');
    
    // 考勤管理年月选择器
    const attendanceYearSelect = document.getElementById('attendance-year');
    const attendanceMonthSelect = document.getElementById('attendance-month');
    
    // 填充年份选项
    for (let year = currentYear - 2; year <= currentYear + 2; year++) {
        [projectYearSelect, attendanceYearSelect].forEach(select => {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year + '年';
            if (year === currentYear) option.selected = true;
            select.appendChild(option);
        });
    }
    
    // 填充月份选项
    for (let month = 1; month <= 12; month++) {
        [projectMonthSelect, attendanceMonthSelect].forEach(select => {
            const option = document.createElement('option');
            option.value = month;
            option.textContent = month + '月';
            if (month === currentMonth) option.selected = true;
            select.appendChild(option);
        });
    }
}

// 页面导航
function showPage(pageId) {
    try {
        // 隐藏所有页面
        document.querySelectorAll('.page-content').forEach(page => {
            if (page && page.style) {
                page.style.display = 'none';
            }
        });
        
        // 移除所有导航项的active类
        document.querySelectorAll('.nav-link').forEach(link => {
            if (link && link.classList) {
                link.classList.remove('active');
            }
        });
        
        // 显示指定页面
        const targetPage = document.getElementById(pageId + '-page');
        if (targetPage && targetPage.style) {
            targetPage.style.display = 'block';
        }
        
        // 添加对应导航项的active类
        const navLink = document.querySelector(`[onclick="showPage('${pageId}')"]`);
        if (navLink && navLink.classList) {
            navLink.classList.add('active');
        }
        
        // 根据页面加载相应数据
        if (pageId === 'projects') {
            loadProjects();
        } else if (pageId === 'attendance') {
            loadAttendance();
        } else if (pageId === 'employees') {
            loadEmployees();
        }
    } catch (error) {
        console.error('页面切换失败:', error);
    }
}

// 项目管理相关函数
async function loadProjects() {
    try {
        const year = document.getElementById('project-year').value;
        const month = document.getElementById('project-month').value;
        
        // 只获取从顶班数据生成的项目数据（项目管理数据完全来源于考勤管理的顶班数据）
        const allProjects = await generateProjectsFromSubstitutes(year, month);
        
        const tbody = document.getElementById('projects-table');
        
        if (!tbody) {
            console.error('projects-table元素未找到');
            showErrorMessage('页面元素加载失败');
            return;
        }
        
        tbody.innerHTML = '';
        
        let totalAmount = 0;
        
        if (allProjects.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td colspan="9" class="text-center text-muted py-4">
                    <i class="bi bi-info-circle"></i> 暂无项目数据
                    <br><small class="text-muted">请先在考勤管理页面设置顶班记录</small>
                </td>
            `;
            tbody.appendChild(row);
        } else {
            // 使用 for...of 循环来支持 await
            for (let index = 0; index < allProjects.length; index++) {
                const project = allProjects[index];
                totalAmount += project.total_amount;
                
                // 构建顶班详情
                let substituteDetails = '';
                try {
                    const detailsList = await getOriginalEmployeesForSubstitute(project.substitute_dates, project.personnel);
                    substituteDetails = detailsList.join('<br>');
                } catch (error) {
                    console.warn('获取顶班详情失败:', error);
                    substituteDetails = '<span class="text-muted">详情获取失败</span>';
                }
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${project.type}</td>
                    <td>${project.monthly_salary.toLocaleString()}</td>
                    <td>${project.daily_salary.toLocaleString()}</td>
                    <td>${project.days}</td>
                    <td>${project.total_amount.toLocaleString()}</td>
                    <td>${project.personnel}</td>
                    <td>${substituteDetails}</td>
                    <td><span class="badge bg-info">来源：考勤顶班</span></td>
                `;
                tbody.appendChild(row);
            }
        }
        
        const totalElement = document.getElementById('total-amount');
        if (totalElement) {
            totalElement.textContent = totalAmount.toLocaleString();
        }
        
    } catch (error) {
        console.error('加载项目数据失败:', error);
        showErrorMessage('加载项目数据失败');
    }
}

// 仅加载顶班项目
async function loadSubstituteProjects() {
    try {
        const year = document.getElementById('project-year').value;
        const month = document.getElementById('project-month').value;
        
        // 只获取从顶班数据生成的项目数据
        const projects = await generateProjectsFromSubstitutes(year, month);
        const tbody = document.getElementById('projects-table');
        
        if (!tbody) {
            console.error('projects-table元素未找到');
            showErrorMessage('页面元素加载失败');
            return;
        }
        
        tbody.innerHTML = '';
        
        let totalAmount = 0;
        
        if (projects.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td colspan="9" class="text-center text-muted py-4">
                    <i class="bi bi-info-circle"></i> 暂无顶班项目数据
                    <br><small class="text-muted">请先在考勤管理页面设置顶班记录</small>
                </td>
            `;
            tbody.appendChild(row);
        } else {
            // 使用 for...of 循环来支持 await
            for (let index = 0; index < projects.length; index++) {
                const project = projects[index];
                totalAmount += project.total_amount;
                
                // 构建顶班详情
                let substituteDetails = '';
                try {
                    const detailsList = await getOriginalEmployeesForSubstitute(project.substitute_dates, project.personnel);
                    substituteDetails = detailsList.join('<br>');
                } catch (error) {
                    console.warn('获取顶班详情失败:', error);
                    substituteDetails = '<span class="text-muted">详情获取失败</span>';
                }
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${project.type}</td>
                    <td>${project.monthly_salary.toLocaleString()}</td>
                    <td>${project.daily_salary.toLocaleString()}</td>
                    <td>${project.days}</td>
                    <td>${project.total_amount.toLocaleString()}</td>
                    <td>${project.personnel}</td>
                    <td>${substituteDetails}</td>
                    <td><span class="badge bg-info">自动生成</span></td>
                `;
                tbody.appendChild(row);
            }
        }
        
        const totalElement = document.getElementById('total-amount');
        if (totalElement) {
            totalElement.textContent = totalAmount.toLocaleString();
        }
        
    } catch (error) {
        console.error('加载顶班项目数据失败:', error);
        showErrorMessage('加载顶班项目数据失败');
    }
}

// 获取被顶班的原员工详细信息
async function getOriginalEmployeesForSubstitute(dates, substituteName) {
    const substituteDetails = [];
    
    if (!dates || !Array.isArray(dates) || !substituteName) {
        return substituteDetails;
    }
    
    try {
        // 确保员工数据已加载
        if (!window.attendanceEmployees || window.attendanceEmployees.length === 0) {
            window.attendanceEmployees = await window.fetchAttendanceEmployees();
        }
        
        // 获取年月信息（从第一个日期推断）
        const firstDate = new Date(dates[0]);
        const year = firstDate.getFullYear();
        const month = firstDate.getMonth() + 1;
        
        // 获取该月的顶班数据
        const substitutes = await window.fetchSubstitutes({ year, month });
        
        // 为每个日期查找对应的顶班记录
        dates.forEach(date => {
            const substituteRecord = substitutes.find(sub => 
                sub.date === date && sub.substitute_name === substituteName
            );
            
            if (substituteRecord) {
                // 查找被顶班的员工信息
                const employee = window.attendanceEmployees.find(emp => emp.id == substituteRecord.employee_id);
                if (employee) {
                    // 获取班次信息
                    const statusText = getStatusDisplayText(substituteRecord.substitute_status);
                    
                    // 格式化日期
                    const dateObj = new Date(date);
                    const year = dateObj.getFullYear();
                    const month = dateObj.getMonth() + 1;
                    const day = dateObj.getDate();
                    
                    // 格式：2025年8月18日顶张三全日班
                    substituteDetails.push(`${year}年${month}月${day}日顶${employee.name}${statusText}班`);
                }
            }
        });
        
    } catch (error) {
        console.error('获取顶班详情失败:', error);
        return ['获取详情失败'];
    }
    
    return substituteDetails;
}

// 获取状态显示文本
function getStatusDisplayText(status) {
    switch (status) {
        case '全': return '全日';
        case '上': return '上午';
        case '下': return '下午';
        case '休': return '休息';
        case '假': return '请假';
        default: return '全日';
    }
}

// 从顶班数据生成项目数据
async function generateProjectsFromSubstitutes(year, month) {
    try {
        // 获取顶班数据
        const substitutes = await window.fetchSubstitutes({ year, month });
        
        if (!substitutes || substitutes.length === 0) {
            return [];
        }
        
        // 按顶班人员分组统计
        const substituteStats = {};
        
        substitutes.forEach(substitute => {
            const key = substitute.substitute_name;
            
            if (!substituteStats[key]) {
                substituteStats[key] = {
                    substitute_name: substitute.substitute_name,
                    substitute_id: substitute.substitute_id,
                    days: 0,
                    dates: []
                };
            }
            
            // 根据顶班状态计算天数：上午班和下午班算0.5天，其他算1天
            let daysToAdd = 1;
            if (substitute.substitute_status === '上' || substitute.substitute_status === '下') {
                daysToAdd = 0.5;
            }
            
            substituteStats[key].days += daysToAdd;
            substituteStats[key].dates.push(substitute.date);
        });
        
        // 生成项目数据
        const projects = [];
        let projectIndex = 1;
        
        for (const [name, stats] of Object.entries(substituteStats)) {
            // 查找顶班人员的实际工资
            let monthlySalary = 5000; // 默认工资标准
            
            // 获取员工数据
            let employees = [];
            try {
                employees = await window.fetchEmployees();
            } catch (error) {
                console.warn('获取员工数据失败，使用默认工资:', error);
            }
            
            // 根据顶班人员姓名查找对应的员工工资
            const employee = employees.find(emp => emp.name === stats.substitute_name);
            if (employee && employee.monthly_salary) {
                monthlySalary = employee.monthly_salary;
            }
            
            const dailySalary = Math.round(monthlySalary / 22); // 日工资标准（按22个工作日计算）
            const totalAmount = dailySalary * stats.days;
            
            projects.push({
                id: projectIndex++,
                type: '顶班补贴',
                monthly_salary: monthlySalary,
                daily_salary: dailySalary,
                days: stats.days,
                total_amount: totalAmount,
                application: `${year}年${month}月顶班申请`,
                personnel: stats.substitute_name,
                substitute_dates: stats.dates.sort()
            });
        }
        
        return projects;
        
    } catch (error) {
        console.error('生成项目数据失败:', error);
        return [];
    }
}

// 显示添加项目模态框
function showAddProjectModal() {
    // 清空表单
    document.getElementById('projectType').value = '';
    document.getElementById('projectMonthlySalary').value = '';
    document.getElementById('projectDailySalary').value = '';
    document.getElementById('projectDays').value = '';
    document.getElementById('projectApplication').value = '';
    document.getElementById('projectPersonnel').value = '';
    
    showModal('projectModal');
}

// 关闭添加项目模态框
function closeProjectModal() {
    closeModal('projectModal');
}

// 添加项目
async function addProject() {
    const type = document.getElementById('projectType').value.trim();
    const monthlySalary = document.getElementById('projectMonthlySalary').value;
    const dailySalary = document.getElementById('projectDailySalary').value;
    const days = document.getElementById('projectDays').value;
    const application = document.getElementById('projectApplication').value.trim();
    const personnel = document.getElementById('projectPersonnel').value.trim();
    
    if (!type || !monthlySalary || !dailySalary || !days || !application || !personnel) {
        showErrorMessage('请填写所有字段');
        return;
    }
    
    try {
        const result = await window.addProject({
            type: type,
            monthly_salary: monthlySalary,
            daily_salary: dailySalary,
            days: days,
            application: application,
            personnel: personnel
        });
        
        if (result.success) {
            closeProjectModal();
            loadProjects();
            showSuccessMessage('项目添加成功');
        } else {
            showErrorMessage(result.message || '添加项目失败');
        }
        
    } catch (error) {
        console.error('添加项目失败:', error);
        showErrorMessage('添加项目失败');
    }
}

// 编辑项目
function editProject(projectId) {
    // 获取项目数据
    window.fetchProjects().then(projects => {
        const project = projects.find(p => p.id == projectId);
        if (!project) {
            showErrorMessage('项目不存在');
            return;
        }
        
        // 填充编辑表单
        document.getElementById('editProjectId').value = project.id;
        document.getElementById('editProjectType').value = project.type;
        document.getElementById('editProjectMonthlySalary').value = project.monthly_salary;
        document.getElementById('editProjectDailySalary').value = project.daily_salary;
        document.getElementById('editProjectDays').value = project.days;
        document.getElementById('editProjectApplication').value = project.application;
        document.getElementById('editProjectPersonnel').value = project.personnel;
        
        showModal('editProjectModal');
    });
}

// 关闭编辑项目模态框
function closeEditProjectModal() {
    closeModal('editProjectModal');
}

// 更新项目
async function updateProject() {
    const projectId = document.getElementById('editProjectId').value;
    const type = document.getElementById('editProjectType').value.trim();
    const monthlySalary = document.getElementById('editProjectMonthlySalary').value;
    const dailySalary = document.getElementById('editProjectDailySalary').value;
    const days = document.getElementById('editProjectDays').value;
    const application = document.getElementById('editProjectApplication').value.trim();
    const personnel = document.getElementById('editProjectPersonnel').value.trim();
    
    if (!type || !monthlySalary || !dailySalary || !days || !application || !personnel) {
        showErrorMessage('请填写所有字段');
        return;
    }
    
    try {
        const result = await window.updateProject(projectId, {
            type: type,
            monthly_salary: monthlySalary,
            daily_salary: dailySalary,
            days: days,
            application: application,
            personnel: personnel
        });
        
        if (result.success) {
            closeEditProjectModal();
            loadProjects();
            showSuccessMessage('项目更新成功');
        } else {
            showErrorMessage(result.message || '更新项目失败');
        }
        
    } catch (error) {
        console.error('更新项目失败:', error);
        showErrorMessage('更新项目失败');
    }
}

// 删除项目确认
function deleteProjectConfirm(projectId, projectType) {
    if (confirm(`确定要删除项目 "${projectType}" 吗？此操作不可撤销。`)) {
        deleteProjectAction(projectId);
    }
}

// 删除项目
async function deleteProjectAction(projectId) {
    try {
        const result = await window.deleteProject(projectId);
        
        if (result.success) {
            loadProjects();
            showSuccessMessage('项目删除成功');
        } else {
            showErrorMessage(result.message || '删除项目失败');
        }
        
    } catch (error) {
        console.error('删除项目失败:', error);
        showErrorMessage('删除项目失败');
    }
}

// 考勤管理相关函数
async function loadAttendance() {
    try {
        // 确保考勤员工已加载
        if (attendanceEmployees.length === 0) {
            await loadAttendanceEmployees();
        }
        
        const year = document.getElementById('attendance-year').value;
        const month = document.getElementById('attendance-month').value;
        
        // 加载考勤数据
        const attendance = await fetchAttendance({ year, month });
        const substitutes = await fetchSubstitutes({ year, month });
        
        // 转换为便于查找的格式
        attendanceData = {};
        attendance.forEach(record => {
            const key = `${record.employee_id}-${record.date}`;
            attendanceData[key] = record;
        });
        
        substituteData = {};
        substitutes.forEach(record => {
            const key = `${record.employee_id}-${record.date}`;
            substituteData[key] = record;
        });
        
        // 生成考勤表格
        generateAttendanceTable(year, month);
        
    } catch (error) {
        console.error('加载考勤数据失败:', error);
        showErrorMessage('加载考勤数据失败');
        // 即使加载失败也要生成表格结构
        const year = document.getElementById('attendance-year').value;
        const month = document.getElementById('attendance-month').value;
        generateAttendanceTable(year, month);
    }
}

function generateAttendanceTable(year, month) {
    const daysInMonth = new Date(year, month, 0).getDate();
    const thead = document.getElementById('attendance-table-head');
    const tbody = document.getElementById('attendance-table');
    
    // 清空现有内容
    if (thead) thead.innerHTML = '';
    if (!tbody) return;
    tbody.innerHTML = '';
    
    // 生成表头
    if (thead) {
        const headerRow1 = document.createElement('tr');
        const headerRow2 = document.createElement('tr');
        
        // 固定列
        headerRow1.innerHTML = `
            <th rowspan="2" class="text-center">序号</th>
            <th rowspan="2" class="text-center">姓名</th>
            <th rowspan="2" class="text-center">岗位</th>
            <th colspan="${daysInMonth}" class="text-center">日期</th>
            <th rowspan="2" class="text-center">出勤</th>
            <th rowspan="2" class="text-center">工作日</th>
            <th rowspan="2" class="text-center">休息日</th>
            <th rowspan="2" class="text-center">请假日</th>
        `;
        
        // 日期列
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month - 1, day);
            const weekDay = ['日', '一', '二', '三', '四', '五', '六'][date.getDay()];
            const th = document.createElement('th');
            th.className = 'text-center date-header';
            th.innerHTML = `${day}<br><small>${weekDay}</small>`;
            headerRow2.appendChild(th);
        }
        
        thead.appendChild(headerRow1);
        thead.appendChild(headerRow2);
    }
    
    // 如果没有考勤员工，显示提示信息
    if (attendanceEmployees.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="${3 + daysInMonth + 4}" class="text-center text-muted py-4">
                <i class="bi bi-info-circle"></i> 暂无考勤员工，请先添加员工到考勤管理
            </td>
        `;
        tbody.appendChild(row);
        return;
    }
    
    attendanceEmployees.forEach((employee, index) => {
        const row = document.createElement('tr');
        
        // 序号、员工信息列
        row.innerHTML = `
            <td class="text-center">${index + 1}</td>
            <td>${employee.name}</td>
            <td>${employee.position}</td>
        `;
        
        // 日期列
        for (let day = 1; day <= daysInMonth; day++) {
            const date = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
            const key = `${employee.id}-${date}`;
            const record = attendanceData[key];
            const substituteRecord = substituteData[key];
            
            const cell = document.createElement('td');
            cell.className = 'attendance-cell text-center';
            cell.setAttribute('data-employee-id', employee.id);
            cell.setAttribute('data-date', date);
            
            let status = '全';
            if (record) {
                status = record.status;
            }
            
            // 更新单元格显示，如果有顶班则传入顶班信息
            updateCellDisplay(cell, status, substituteRecord);
            
            // 添加事件监听器
            cell.addEventListener('click', function(e) {
                console.log('单元格点击事件触发:', this);
                e.preventDefault();
                e.stopPropagation();
                toggleAttendanceStatus(this);
            });
            
            cell.addEventListener('contextmenu', function(e) {
                e.preventDefault();
                e.stopPropagation();
                showSubstituteMenu(e, this);
            });
            
            row.appendChild(cell);
        }
        
        // 统计列
        const stats = calculateEmployeeStats(employee.id, year, month);
        
        // 创建统计列的单元格
        const attendanceDaysCell = document.createElement('td');
        attendanceDaysCell.className = 'text-center';
        attendanceDaysCell.textContent = stats.workDays;
        row.appendChild(attendanceDaysCell);
        
        const workDaysCell = document.createElement('td');
        workDaysCell.className = 'text-center';
        workDaysCell.textContent = stats.workDays;
        row.appendChild(workDaysCell);
        
        const restDaysCell = document.createElement('td');
        restDaysCell.className = 'text-center';
        restDaysCell.textContent = stats.restDays;
        row.appendChild(restDaysCell);
        
        const leaveDaysCell = document.createElement('td');
        leaveDaysCell.className = 'text-center';
        leaveDaysCell.textContent = stats.leaveDays;
        row.appendChild(leaveDaysCell);
        
        tbody.appendChild(row);
    });
}

function updateEmployeeStats(employeeId) {
    const year = document.getElementById('attendance-year').value;
    const month = document.getElementById('attendance-month').value;
    
    // 找到对应的员工行
    const employeeIndex = attendanceEmployees.findIndex(emp => emp.id == employeeId);
    if (employeeIndex === -1) return;
    
    const tbody = document.getElementById('attendance-table');
    const row = tbody.children[employeeIndex];
    if (!row) return;
    
    // 计算统计数据
    const stats = calculateEmployeeStats(employeeId, year, month);
    
    // 更新统计列（从右往左数第4、3、2、1列）
    const cells = row.children;
    const totalCells = cells.length;
    cells[totalCells - 4].textContent = stats.workDays; // 出勤
    cells[totalCells - 3].textContent = stats.workDays; // 工作日
    cells[totalCells - 2].textContent = stats.restDays; // 休息日
    cells[totalCells - 1].textContent = stats.leaveDays; // 请假日
}

function calculateEmployeeStats(employeeId, year, month) {
    const daysInMonth = new Date(year, month, 0).getDate();
    let workDays = 0;
    let restDays = 0;
    let leaveDays = 0;
    
    for (let day = 1; day <= daysInMonth; day++) {
        const date = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
        const key = `${employeeId}-${date}`;
        const record = attendanceData[key];
        const substituteRecord = substituteData[key];
        
        let status = '全';
        if (record) {
            status = record.status;
        }
        
        if (substituteRecord) {
            if (status === '全') {
                leaveDays++;
            } else if (status === '上' || status === '下') {
                leaveDays += 0.5;
            } else if (status === '休') {
                restDays++;
            } else if (status === '假') {
                leaveDays++;
            }
        } else {
            if (status === '休') {
                restDays++;
            } else if (status === '假') {
                leaveDays++;
            } else if (status === '上' || status === '下') {
                workDays += 0.5;
                restDays += 0.5;
            } else {
                workDays++;
            }
        }
    }
    
    return {
        workDays: workDays % 1 === 0 ? workDays : workDays.toFixed(1),
        restDays: restDays % 1 === 0 ? restDays : restDays.toFixed(1),
        leaveDays: leaveDays % 1 === 0 ? leaveDays : leaveDays.toFixed(1)
    };
}

function getStatusDisplay(status) {
    switch (status) {
        case '全': return '全';
        case '休': return '休';
        case '上': return '上';
        case '下': return '下';
        case '假': return '假';
        case '顶': return '顶';
        default: return '全';
    }
}

// 切换考勤状态
async function toggleAttendanceStatus(cell) {
    console.log('点击考勤单元格:', cell);
    
    const employeeId = cell.getAttribute('data-employee-id');
    const date = cell.getAttribute('data-date');
    const key = `${employeeId}-${date}`;
    
    console.log('员工ID:', employeeId, '日期:', date);
    
    // 检查当前状态
    const hasSubstitute = substituteData[key];
    const currentStatus = getCurrentStatusFromCell(cell);
    
    console.log('当前状态:', currentStatus, '有顶班:', !!hasSubstitute);
    
    // 状态循环：全日班 -> 休息 -> 上午班 -> 下午班 -> 请假 -> 全日班（移除顶班状态）
    const statusCycle = ['全', '休', '上', '下', '假'];
    let currentIndex = statusCycle.indexOf(currentStatus);
    
    // 如果当前状态不在循环中（比如"顶"），默认从"全"开始
    if (currentIndex === -1) {
        currentIndex = 0; // 从"全"开始
    }
    
    const nextIndex = (currentIndex + 1) % statusCycle.length;
    const nextStatus = statusCycle[nextIndex];
    
    console.log('下一个状态:', nextStatus);
    
    try {
        // 如果之前有顶班，先清除顶班
        if (hasSubstitute) {
            await deleteSubstitute(employeeId, date);
            delete substituteData[key];
            cell.classList.remove('has-substitute');
            cell.title = '';
            cell.style.border = '';
        }
        
        await addOrUpdateAttendance({
            employee_id: employeeId,
            date: date,
            status: nextStatus
        });
        
        // 更新单元格显示
        updateCellDisplay(cell, nextStatus);
        
        // 更新本地数据
        attendanceData[key] = {
            employee_id: parseInt(employeeId),
            date: date,
            status: nextStatus
        };
        
        // 更新统计信息
        updateEmployeeStats(employeeId);
        
        showSuccessMessage('考勤状态已更新');
        
    } catch (error) {
        console.error('更新考勤状态失败:', error);
        showErrorMessage('更新考勤状态失败');
    }
}

function getCurrentStatusFromCell(cell) {
    // 检查是否有顶班的HTML结构
    const originalStatusElement = cell.querySelector('.original-status');
    if (originalStatusElement) {
        // 有顶班时，从original-status元素获取状态
        const text = originalStatusElement.textContent.trim();
        switch (text) {
            case '全': return '全';
            case '休': return '休';
            case '上': return '上';
            case '下': return '下';
            case '假': return '假';
            case '顶': return '顶';
            default: return '全';
        }
    } else {
        // 没有顶班时，直接从单元格文本内容获取状态
        const text = cell.textContent.trim();
        switch (text) {
            case '全': return '全';
            case '休': return '休';
            case '上': return '上';
            case '下': return '下';
            case '假': return '假';
            case '顶': return '顶';
            default: return '全';
        }
    }
}

function updateCellDisplay(cell, status, substituteInfo = null) {
    // 移除所有状态类
    cell.className = 'attendance-cell text-center';
    
    // 添加新状态类
    switch (status) {
        case '休':
            cell.classList.add('status-rest');
            break;
        case '上':
            cell.classList.add('status-morning');
            break;
        case '下':
            cell.classList.add('status-afternoon');
            break;
        case '假':
            cell.classList.add('status-leave');
            break;
        case '顶':
            cell.classList.add('status-substitute');
            break;
        case '全':
        default:
            cell.classList.add('status-work');
            break;
    }

    // 检查是否有顶班信息
    const employeeId = cell.getAttribute('data-employee-id');
    const date = cell.getAttribute('data-date');
    const key = `${employeeId}-${date}`;
    const hasSubstitute = substituteData[key] || substituteInfo;
    
    if (hasSubstitute) {
        // 有顶班时，显示原状态 + 分割线 + 顶班人员姓名
        cell.classList.add('has-substitute');
        cell.innerHTML = `
            <div class="cell-content">
                <div class="original-status">${getStatusDisplay(status)}</div>
                <div class="divider-line"></div>
                <div class="substitute-name">${hasSubstitute.substitute_name}</div>
            </div>
        `;
        cell.title = `有顶班: ${hasSubstitute.substitute_name}`;
    } else {
        // 没有顶班时，只显示状态
        cell.textContent = getStatusDisplay(status);
        cell.title = '';
    }
}

// 显示顶班选择模态框
function showSubstituteSelectionModal(cell) {
    currentContextCell = cell;
    
    const modal = document.getElementById('substituteSelectionModal');
    const select = document.getElementById('substituteEmployeeSelect');
    
    // 清空选项
    select.innerHTML = '<option value="">请选择顶班员工</option>';
    
    // 添加员工选项
    attendanceEmployees.forEach(employee => {
        const option = document.createElement('option');
        option.value = employee.id;
        option.textContent = employee.name;
        select.appendChild(option);
    });
    
    showModal('substituteSelectionModal');
}

// 关闭顶班选择模态框
function closeSubstituteSelectionModal() {
    closeModal('substituteSelectionModal');
    currentContextCell = null;
}

// 确认设置顶班
async function confirmSubstitute() {
    if (!currentContextCell) return;
    
    const select = document.getElementById('substituteEmployeeSelect');
    const substituteId = select.value;
    
    if (!substituteId) {
        showErrorMessage('请选择顶班员工');
        return;
    }
    
    const substituteEmployee = attendanceEmployees.find(emp => emp.id == substituteId);
    if (!substituteEmployee) {
        showErrorMessage('找不到选择的员工');
        return;
    }
    
    const employeeId = currentContextCell.getAttribute('data-employee-id');
    const date = currentContextCell.getAttribute('data-date');
    const currentStatus = getCurrentStatusFromCell(currentContextCell);
    
    try {
        const substituteInfo = {
            employee_id: employeeId,
            date: date,
            substitute_id: substituteEmployee.id,
            substitute_name: substituteEmployee.name,
            substitute_status: currentStatus === '顶' ? '全' : currentStatus
        };
        
        await addOrUpdateSubstitute(substituteInfo);
        
        // 更新本地数据
        const key = `${employeeId}-${date}`;
        substituteData[key] = substituteInfo;
        
        // 更新单元格显示，传入顶班信息
        updateCellDisplay(currentContextCell, currentStatus === '顶' ? '全' : currentStatus, substituteInfo);
        
        closeSubstituteSelectionModal();
        showSuccessMessage(`已设置 ${substituteEmployee.name} 顶班`);
        
    } catch (error) {
        console.error('设置顶班失败:', error);
        showErrorMessage('设置顶班失败');
    }
}

// 显示顶班菜单
function showSubstituteMenu(event, cell) {
    event.preventDefault();
    currentContextCell = cell;
    
    console.log('显示顶班菜单，考勤员工数量:', attendanceEmployees.length);
    
    const contextMenu = document.getElementById('contextMenu');
    const substituteList = document.getElementById('substituteList');
    
    if (!contextMenu || !substituteList) {
        console.error('找不到右键菜单元素');
        return;
    }
    
    // 清空现有列表
    substituteList.innerHTML = '';
    
    // 添加员工选项
    if (attendanceEmployees.length === 0) {
        const noEmployees = document.createElement('div');
        noEmployees.className = 'context-menu-item';
        noEmployees.textContent = '暂无考勤员工';
        noEmployees.style.color = '#999';
        noEmployees.style.fontStyle = 'italic';
        substituteList.appendChild(noEmployees);
    } else {
        attendanceEmployees.forEach(employee => {
            const option = document.createElement('div');
            option.className = 'context-menu-item';
            option.textContent = employee.name;
            option.onclick = () => setSubstitute(employee);
            substituteList.appendChild(option);
        });
    }
    
    // 确保菜单在视口内
    const menuWidth = 200;
    const menuHeight = Math.min(300, 60 + attendanceEmployees.length * 32 + 50);
    
    let left = event.pageX;
    let top = event.pageY;
    
    // 检查右边界
    if (left + menuWidth > window.innerWidth) {
        left = window.innerWidth - menuWidth - 10;
    }
    
    // 检查下边界
    if (top + menuHeight > window.innerHeight) {
        top = window.innerHeight - menuHeight - 10;
    }
    
    // 确保不超出左边界和上边界
    left = Math.max(10, left);
    top = Math.max(10, top);
    
    // 显示菜单
    contextMenu.style.display = 'block';
    contextMenu.style.left = left + 'px';
    contextMenu.style.top = top + 'px';
    contextMenu.style.zIndex = '9999';
    
    console.log('右键菜单已显示，位置:', left, top);
}

// 设置顶班
async function setSubstitute(substituteEmployee) {
    if (!currentContextCell) return;
    
    const employeeId = currentContextCell.getAttribute('data-employee-id');
    const date = currentContextCell.getAttribute('data-date');
    const currentStatus = getCurrentStatusFromCell(currentContextCell);
    
    try {
        const substituteInfo = {
            employee_id: employeeId,
            date: date,
            substitute_id: substituteEmployee.id,
            substitute_name: substituteEmployee.name,
            substitute_status: currentStatus
        };
        
        await addOrUpdateSubstitute(substituteInfo);
        
        // 更新本地数据
        const key = `${employeeId}-${date}`;
        substituteData[key] = substituteInfo;
        
        // 更新单元格显示，传入顶班信息
        updateCellDisplay(currentContextCell, currentStatus, substituteInfo);
        
        hideContextMenu();
        showSuccessMessage(`已设置 ${substituteEmployee.name} 顶班`);
        
    } catch (error) {
        console.error('设置顶班失败:', error);
        showErrorMessage('设置顶班失败');
    }
}

// 清除顶班
async function clearSubstitute() {
    if (!currentContextCell) return;
    
    const employeeId = currentContextCell.getAttribute('data-employee-id');
    const date = currentContextCell.getAttribute('data-date');
    
    try {
        await deleteSubstitute(employeeId, date);
        
        // 清除本地数据
        const key = `${employeeId}-${date}`;
        delete substituteData[key];
        
        // 获取当前状态并重新显示单元格（不带顶班信息）
        const currentStatus = getCurrentStatusFromCell(currentContextCell);
        updateCellDisplay(currentContextCell, currentStatus);
        
        hideContextMenu();
        showSuccessMessage('已清除顶班');
        
    } catch (error) {
        console.error('清除顶班失败:', error);
        showErrorMessage('清除顶班失败');
    }
}

// 隐藏右键菜单
function hideContextMenu() {
    document.getElementById('contextMenu').style.display = 'none';
    currentContextCell = null;
}

// 员工管理相关函数
async function loadEmployees() {
    try {
        const employees = await fetchEmployees();
        const tbody = document.getElementById('employees-table');
        tbody.innerHTML = '';
        
        employees.forEach(employee => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${employee.id}</td>
                <td>${employee.name}</td>
                <td>${employee.position}</td>
                <td>${employee.monthly_salary}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editMonthlySalary(${employee.id}, '${employee.name}', ${employee.monthly_salary})">
                        编辑工资
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteEmployeeConfirm(${employee.id}, '${employee.name}')">
                        删除
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
        
    } catch (error) {
        console.error('加载员工数据失败:', error);
        showErrorMessage('加载员工数据失败');
    }
}

// 添加员工
function showAddEmployeeModal() {
    document.getElementById('employeeName').value = '';
    document.getElementById('employeePosition').value = '';
    document.getElementById('employeeSalary').value = '';
    showModal('employeeModal');
}

function closeEmployeeModal() {
    closeModal('employeeModal');
}

async function addEmployeeHandler() {
    const name = document.getElementById('employeeName').value.trim();
    const position = document.getElementById('employeePosition').value.trim();
    const salary = document.getElementById('employeeSalary').value;
    
    if (!name || !position || !salary) {
        showErrorMessage('请填写所有字段');
        return;
    }
    
    try {
        // 调用local-api.js中的addEmployee函数
        const result = await addEmployee({
            name: name,
            position: position,
            monthly_salary: parseInt(salary)
        });
        
        if (result.success) {
            closeEmployeeModal();
            loadEmployees();
            showSuccessMessage('员工添加成功');
        } else {
            showErrorMessage(result.message || '添加员工失败');
        }
        
    } catch (error) {
        console.error('添加员工失败:', error);
        showErrorMessage('添加员工失败');
    }
}

// 编辑员工工资
function editMonthlySalary(employeeId, employeeName, currentSalary) {
    document.getElementById('editEmployeeId').value = employeeId;
    document.getElementById('editEmployeeName').value = employeeName;
    document.getElementById('editEmployeeSalary').value = currentSalary;
    showModal('salaryModal');
}

function closeEditSalaryModal() {
    closeModal('salaryModal');
}

function closeSalaryModal() {
    closeModal('salaryModal');
}

async function updateEmployeeSalary() {
    const employeeId = document.getElementById('editEmployeeId').value;
    const newSalary = document.getElementById('editEmployeeSalary').value;
    
    if (!newSalary || newSalary <= 0) {
        showErrorMessage('请输入有效的工资金额');
        return;
    }
    
    try {
        await updateEmployee(employeeId, {
            monthly_salary: parseInt(newSalary)
        });
        
        closeEditSalaryModal();
        loadEmployees();
        showSuccessMessage('工资更新成功');
        
    } catch (error) {
        console.error('更新工资失败:', error);
        showErrorMessage('更新工资失败');
    }
}

// 删除员工
function deleteEmployeeConfirm(employeeId, employeeName) {
    if (confirm(`确定要删除员工 ${employeeName} 吗？此操作不可撤销。`)) {
        deleteEmployeeAction(employeeId);
    }
}

async function deleteEmployeeAction(employeeId) {
    try {
        const result = await deleteEmployee(employeeId);
        
        // 刷新员工管理页面
        loadEmployees();
        
        // 刷新考勤相关数据
        if (typeof loadAttendanceEmployees === 'function') {
            await loadAttendanceEmployees();
        }
        if (typeof loadAttendance === 'function') {
            await loadAttendance();
        }
        
        // 显示详细的删除结果
        if (result.deletedRecords) {
            const { attendance, substitutes, projects } = result.deletedRecords;
            let message = '员工删除成功';
            if (attendance > 0 || substitutes > 0 || projects > 0) {
                message += `\n同时清理了相关数据：`;
                if (attendance > 0) message += `\n- 考勤记录：${attendance}条`;
                if (substitutes > 0) message += `\n- 顶班记录：${substitutes}条`;
                if (projects > 0) message += `\n- 项目记录：${projects}条`;
            }
            showSuccessMessage(message);
        } else {
            showSuccessMessage('员工删除成功');
        }
        
    } catch (error) {
        console.error('删除员工失败:', error);
        showErrorMessage('删除员工失败');
    }
}

// 考勤员工管理
async function loadAttendanceEmployees() {
    try {
        attendanceEmployees = await fetchAttendanceEmployees();
        console.log('考勤员工已加载:', attendanceEmployees.length, '人');
    } catch (error) {
        console.error('加载考勤员工失败:', error);
        attendanceEmployees = [];
    }
}

// 显示添加考勤员工模态框
function showAddAttendanceEmployeeModal() {
    const modal = document.getElementById('addAttendanceEmployeeModal');
    const select = document.getElementById('addAttendanceEmployeeSelect');
    
    // 清空选项
    select.innerHTML = '<option value="">请选择员工</option>';
    
    // 加载所有员工，排除已在考勤管理中的员工
    fetchEmployees().then(allEmployees => {
        const availableEmployees = allEmployees.filter(emp => 
            !attendanceEmployees.find(attEmp => attEmp.id == emp.id)
        );
        
        availableEmployees.forEach(employee => {
            const option = document.createElement('option');
            option.value = employee.id;
            option.textContent = `${employee.name} - ${employee.position}`;
            select.appendChild(option);
        });
    });
    
    showModal('addAttendanceEmployeeModal');
}

// 关闭添加考勤员工模态框
function closeAddAttendanceEmployeeModal() {
    closeModal('addAttendanceEmployeeModal');
}

// 添加考勤员工
async function addAttendanceEmployee() {
    try {
        const select = document.getElementById('addAttendanceEmployeeSelect');
        const employeeId = select.value;
        
        if (!employeeId) {
            showErrorMessage('请选择要添加的员工');
            return;
        }
        
        const result = await addAttendanceEmployeeAPI(employeeId);
        
        if (result.success) {
            // 重新加载考勤员工和考勤数据
            await loadAttendanceEmployees();
            await loadAttendance();
            
            closeAddAttendanceEmployeeModal();
            showSuccessMessage('员工已添加到考勤管理');
        } else {
            showErrorMessage(result.message || '添加失败');
        }
    } catch (error) {
        console.error('添加考勤员工失败:', error);
        showErrorMessage(error.message || '添加失败');
    }
}

// 显示删除考勤员工模态框
function showDeleteAttendanceEmployeeModal() {
    const modal = document.getElementById('deleteAttendanceEmployeeModal');
    const select = document.getElementById('deleteAttendanceEmployeeSelect');
    
    // 清空选项
    select.innerHTML = '<option value="">请选择员工</option>';
    
    // 加载考勤员工
    attendanceEmployees.forEach(employee => {
        const option = document.createElement('option');
        option.value = employee.id;
        option.textContent = `${employee.name} - ${employee.position}`;
        select.appendChild(option);
    });
    
    showModal('deleteAttendanceEmployeeModal');
}

// 关闭删除考勤员工模态框
function closeDeleteAttendanceEmployeeModal() {
    closeModal('deleteAttendanceEmployeeModal');
}

// 删除考勤员工
async function deleteAttendanceEmployee() {
    try {
        const select = document.getElementById('deleteAttendanceEmployeeSelect');
        const employeeId = select.value;
        
        if (!employeeId) {
            showErrorMessage('请选择要删除的员工');
            return;
        }
        
        // 从考勤员工列表中删除
        const result = await deleteAttendanceEmployeeAPI(employeeId);
        
        if (result.success) {
            // 重新加载考勤员工和考勤数据
            await loadAttendanceEmployees();
            await loadAttendance();
            
            closeDeleteAttendanceEmployeeModal();
            showSuccessMessage('员工已从考勤中删除');
        } else {
            showErrorMessage(result.message || '删除失败');
        }
    } catch (error) {
        console.error('删除考勤员工失败:', error);
        showErrorMessage('删除失败');
    }
}

// 通用模态框函数
function showModal(modalId) {
    const modalElement = document.getElementById(modalId);
    modalElement.style.display = 'block';
    modalElement.classList.add('show');
    document.body.classList.add('modal-open');
    
    // 添加背景遮罩
    let backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop fade show';
    backdrop.id = modalId + '-backdrop';
    document.body.appendChild(backdrop);
    
    // 添加点击背景关闭功能
    backdrop.onclick = () => closeModal(modalId);
    
    // 添加ESC键关闭功能
    const handleEscape = (e) => {
        if (e.key === 'Escape') {
            closeModal(modalId);
            document.removeEventListener('keydown', handleEscape);
        }
    };
    document.addEventListener('keydown', handleEscape);
}

function closeModal(modalId) {
    const modalElement = document.getElementById(modalId);
    modalElement.style.display = 'none';
    modalElement.classList.remove('show');
    document.body.classList.remove('modal-open');
    
    // 移除背景遮罩
    const backdrop = document.getElementById(modalId + '-backdrop');
    if (backdrop) {
        backdrop.remove();
    }
}

// Excel导出功能
async function exportAttendanceToExcel() {
    try {
        // 检查XLSX库是否加载
        if (typeof XLSX === 'undefined') {
            showErrorMessage('Excel库未加载，请刷新页面重试');
            return;
        }
        
        const year = document.getElementById('attendance-year').value;
        const month = document.getElementById('attendance-month').value;
        
        if (!year || !month) {
            showErrorMessage('请选择年份和月份');
            return;
        }
        
        // 先加载考勤数据，确保数据是最新的
        await loadAttendance();
        
        // 检查是否有考勤员工数据
        if (!attendanceEmployees || attendanceEmployees.length === 0) {
            showErrorMessage('没有考勤员工数据，请先添加考勤员工');
            return;
        }
        
        const daysInMonth = new Date(year, month, 0).getDate();
        
        // 准备数据
        const data = [];
        
        // 添加标题行
        const headers = ['序号', '姓名', '岗位'];
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month - 1, day);
            const weekDay = ['日', '一', '二', '三', '四', '五', '六'][date.getDay()];
            headers.push(`${day}日(${weekDay})`);
        }
        headers.push('出勤天数', '工作日', '休息日', '请假日');
        data.push(headers);
        
        // 添加员工数据
        attendanceEmployees.forEach((employee, index) => {
            const row = [index + 1, employee.name, employee.position];
            
            // 计算统计数据
            const stats = calculateEmployeeStats(employee.id, year, month);
            
            for (let day = 1; day <= daysInMonth; day++) {
                const date = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                const key = `${employee.id}-${date}`;
                const record = attendanceData[key];
                const substituteRecord = substituteData[key];
                
                let status = '全';
                if (record) {
                    status = record.status;
                }
                
                let cellValue = getStatusDisplay(status);
                if (substituteRecord) {
                    cellValue += `(${substituteRecord.substitute_name}顶班)`;
                }
                
                row.push(cellValue);
            }
            
            // 添加统计数据
            row.push(
                stats.workDays,
                stats.workDays,
                stats.restDays,
                stats.leaveDays
            );
            
            data.push(row);
        });
        
        // 创建工作簿
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(data);
        
        // 设置列宽
        const colWidths = [
            { wch: 6 },  // 序号
            { wch: 10 }, // 姓名
            { wch: 12 }, // 岗位
        ];
        
        // 日期列
        for (let i = 0; i < daysInMonth; i++) {
            colWidths.push({ wch: 4 });
        }
        
        // 统计列
        colWidths.push({ wch: 6 }, { wch: 8 }, { wch: 8 }, { wch: 8 });
        
        ws['!cols'] = colWidths;
        
        XLSX.utils.book_append_sheet(wb, ws, '考勤表');
        
        // 导出文件
        const filename = `考勤表_${year}年${month}月.xlsx`;
        XLSX.writeFile(wb, filename);
        
        showSuccessMessage('考勤表导出成功');
    } catch (error) {
        console.error('导出失败:', error);
        showErrorMessage('导出失败');
    }
}

async function exportProjectsToExcel() {
    try {
        // 检查XLSX库是否加载
        if (typeof XLSX === 'undefined') {
            showErrorMessage('Excel库未加载，请刷新页面重试');
            return;
        }
        
        const year = document.getElementById('project-year').value;
        const month = document.getElementById('project-month').value;
        
        if (!year || !month) {
            showErrorMessage('请选择年份和月份');
            return;
        }
        
        console.log('开始导出Excel，年份:', year, '月份:', month);
        console.log('XLSX库状态:', typeof XLSX, XLSX.version);
        
        // 只获取从顶班数据生成的项目数据（项目管理数据完全来源于考勤管理的顶班数据）
        let projects = [];
        try {
            projects = await generateProjectsFromSubstitutes(year, month) || [];
            console.log('顶班项目数据:', projects);
        } catch (error) {
            console.warn('生成顶班项目数据失败:', error);
            projects = [];
        }
        
        projects = projects.filter(project => project != null);
        
        if (projects.length === 0) {
            showErrorMessage('没有可导出的项目数据');
            return;
        }
        
        const data = [];
        
        // 添加标题行
        const headers = ['序号', '加班类型', '月工资标准(元/月)', '日工资标准(元/天)', '天数', '合计金额(元)', '项目人员', '顶班详情', '数据来源'];
        data.push(headers);
        console.log('标题行:', headers);
        
        let totalAmount = 0;
        
        // 添加数据行
        for (let index = 0; index < projects.length; index++) {
            try {
                const project = projects[index];
                if (!project) continue;
                
                const projectAmount = Number(project.total_amount) || 0;
                totalAmount += projectAmount;
                
                // 构建顶班详情
                let substituteDetails = '-';
                if (project.substitute_dates && Array.isArray(project.substitute_dates) && project.substitute_dates.length > 0 && project.personnel) {
                    try {
                        const detailsList = await getOriginalEmployeesForSubstitute(project.substitute_dates, project.personnel);
                        if (detailsList && Array.isArray(detailsList) && detailsList.length > 0) {
                            substituteDetails = detailsList.join(' ');
                        }
                    } catch (detailError) {
                        console.warn('获取顶班详情失败:', detailError);
                        substituteDetails = '详情获取失败';
                    }
                }
                
                // 数据来源（现在所有项目都来源于考勤顶班）
                const dataSource = '来源：考勤顶班';
                
                const row = [
                    index + 1,
                    String(project.type || ''),
                    Number(project.monthly_salary) || 0,
                    Number(project.daily_salary) || 0,
                    Number(project.days) || 0,
                    projectAmount,
                    String(project.personnel || ''),
                    String(substituteDetails),
                    dataSource
                ];
                
                data.push(row);
                console.log(`第${index + 1}行数据:`, row);
            } catch (rowError) {
                console.warn(`处理第${index + 1}行数据失败:`, rowError);
            }
        }
        
        // 添加合计行
        const totalRow = ['', '', '', '', '', `合计: ${totalAmount.toLocaleString()}`, '', '', ''];
        data.push(totalRow);
        console.log('合计行:', totalRow);
        
        console.log('完整数据数组:', data);
        
        // 检查XLSX.utils是否存在
        if (!XLSX.utils || typeof XLSX.utils.book_new !== 'function') {
            throw new Error('XLSX.utils未正确加载');
        }
        
        // 创建工作簿
        console.log('创建工作簿...');
        const wb = XLSX.utils.book_new();
        
        // 检查XLSX.utils.aoa_to_sheet是否存在
        if (typeof XLSX.utils.aoa_to_sheet !== 'function') {
            throw new Error('XLSX.utils.aoa_to_sheet函数不存在');
        }
        
        console.log('转换数据为工作表...');
        const ws = XLSX.utils.aoa_to_sheet(data);
        
        // 设置列宽
        ws['!cols'] = [
            { wch: 6 },  // 序号
            { wch: 10 }, // 加班类型
            { wch: 15 }, // 月工资标准
            { wch: 15 }, // 日工资标准
            { wch: 8 },  // 天数
            { wch: 12 }, // 合计金额
            { wch: 12 }, // 项目人员
            { wch: 30 }, // 顶班详情
            { wch: 12 }  // 数据来源
        ];
        
        console.log('添加工作表到工作簿...');
        XLSX.utils.book_append_sheet(wb, ws, '项目明细');
        
        // 导出文件
        const filename = `项目明细_${year}年${month}月.xlsx`;
        console.log('导出文件:', filename);
        
        // 检查XLSX.writeFile是否存在
        if (typeof XLSX.writeFile !== 'function') {
            throw new Error('XLSX.writeFile函数不存在');
        }
        
        XLSX.writeFile(wb, filename);
        
        showSuccessMessage('项目明细导出成功');
        console.log('Excel导出完成');
    } catch (error) {
        console.error('导出失败详细信息:', error);
        console.error('错误堆栈:', error.stack);
        console.error('错误名称:', error.name);
        console.error('错误消息:', error.message);
        
        // 提供更详细的错误信息
        let errorMessage = '导出失败';
        if (error.message) {
            errorMessage += ': ' + error.message;
        }
        if (error.name) {
            errorMessage += ' (' + error.name + ')';
        }
        
        showErrorMessage(errorMessage);
    }
}

// 点击页面其他地方隐藏右键菜单
document.addEventListener('click', function(event) {
    const contextMenu = document.getElementById('contextMenu');
    if (contextMenu && !contextMenu.contains(event.target)) {
        hideContextMenu();
    }
});
# 排班管理系统 - Vercel 部署包

## 📦 包含文件
- public
- server.js
- package.json
- vercel.json
- db.js
- README.md

## 🚀 部署步骤
1. 上传此压缩包到 Vercel
2. 配置环境变量：
   - DATABASE_URL: PostgreSQL 连接字符串
   - NODE_ENV: production
3. 部署完成后测试功能

## 📝 注意事项
- 确保已设置 Supabase 数据库
- 环境变量必须在 Vercel 控制台中配置
- 首次部署后需要重新部署以应用环境变量

生成时间: 2025/8/2 17:06:54

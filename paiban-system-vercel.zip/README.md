# 排班管理系统

一个基于Node.js和Express的现代化排班管理系统，支持项目管理、员工管理和考勤管理。

## 功能特性

### 📋 项目管理
- 项目明细录入和编辑
- 工资标准和天数计算
- 项目金额自动计算
- 项目人员分配管理

### 👥 员工管理
- 员工信息维护
- 岗位分类管理
- 员工档案查看

### 📅 考勤管理
- 月度考勤表格
- 多种考勤状态支持（正常、休息、请假、病假、事假、迟到、早退）
- 工作时间和加班时间记录
- 考勤统计和汇总

## 技术栈

- **后端**: Node.js + Express
- **数据库**: SQLite3
- **前端**: HTML5 + CSS3 + JavaScript
- **UI框架**: Bootstrap 5
- **图标**: Bootstrap Icons

## 安装和运行

### 1. 安装依赖
```bash
npm install
```

### 2. 启动服务器
```bash
# 生产环境
npm start

# 开发环境（需要安装nodemon）
npm run dev
```

### 3. 访问系统
打开浏览器访问: http://localhost:3000

## 系统截图

系统包含三个主要模块：

1. **项目管理**: 管理各类项目的工资标准、天数和金额
2. **考勤管理**: 记录员工每日考勤状态和工作时间
3. **员工管理**: 维护员工基本信息和岗位

## 数据库结构

### projects 表
- id: 主键
- sequence: 序号
- category: 加班类型
- unit_price: 工资标准(元/月)
- daily_standard: 日调岗工资标准(元/天)
- days: 天数
- total_amount: 合计金额
- project_period: 项目申请
- responsible_person: 项目人员

### employees 表
- id: 主键
- name: 姓名
- position: 岗位

### attendance 表
- id: 主键
- employee_id: 员工ID
- date: 日期
- status: 考勤状态
- work_hours: 工作小时
- overtime_hours: 加班小时
- notes: 备注

## API接口

### 项目管理
- GET /api/projects - 获取所有项目
- POST /api/projects - 添加项目
- PUT /api/projects/:id - 更新项目
- DELETE /api/projects/:id - 删除项目

### 员工管理
- GET /api/employees - 获取所有员工
- POST /api/employees - 添加员工

### 考勤管理
- GET /api/attendance - 获取考勤记录
- POST /api/attendance - 添加/更新考勤记录
- GET /api/attendance/summary/:year/:month - 获取月度考勤汇总

## 使用说明

### 项目管理
1. 点击"添加项目"按钮创建新项目
2. 填写项目信息，系统会自动计算总金额
3. 可以编辑或删除现有项目

### 员工管理
1. 点击"添加员工"按钮添加新员工
2. 选择相应的岗位类型

### 考勤管理
1. 选择年份和月份查看考勤表
2. 点击日期单元格编辑考勤状态
3. 支持多种考勤状态和工时记录
4. 系统自动统计出勤天数

## 注意事项

- 系统使用SQLite数据库，数据文件为`paiban.db`
- 首次运行会自动创建数据库表和示例数据
- 考勤状态支持：√（正常）、休（休息）、假（请假）、病（病假）、事（事假）、迟（迟到）、早（早退）
- 项目金额会根据日工资标准和天数自动计算

## 开发者

如需定制开发或技术支持，请联系开发团队。
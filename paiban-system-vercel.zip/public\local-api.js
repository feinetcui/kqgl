// 本地存储版本的API函数
// 这些函数模拟后端API，使用localStorage存储数据

// 存储键名常量
const STORAGE_KEYS = {
    EMPLOYEES: 'paiban_employees',
    ATTENDANCE: 'paiban_attendance',
    SUBSTITUTES: 'paiban_substitutes',
    ATTENDANCE_EMPLOYEES: 'paiban_attendance_employees',
    PROJECTS: 'paiban_projects'
};

// 工具函数：生成唯一ID
function generateId() {
    return Date.now() + Math.random().toString(36).substr(2, 9);
}

// 工具函数：获取存储数据
function getStorageData(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : [];
    } catch (error) {
        console.error(`获取存储数据失败 (${key}):`, error);
        return [];
    }
}

// 工具函数：保存存储数据
function setStorageData(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error(`保存存储数据失败 (${key}):`, error);
        return false;
    }
}

// 初始化默认数据
function initializeDefaultData() {
    // 初始化默认员工
    const employees = getStorageData(STORAGE_KEYS.EMPLOYEES);
    if (employees.length === 0) {
        const defaultEmployees = [
            { id: 1, name: '张三', position: '技术员', monthly_salary: 5000 },
            { id: 2, name: '李四', position: '操作员', monthly_salary: 4000 },
            { id: 3, name: '王五', position: '维修员', monthly_salary: 4500 }
        ];
        setStorageData(STORAGE_KEYS.EMPLOYEES, defaultEmployees);
        
        // 初始化默认考勤员工
        setStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES, defaultEmployees);
    }
}

// 员工管理API
async function fetchEmployees() {
    return new Promise((resolve) => {
        setTimeout(() => {
            const employees = getStorageData(STORAGE_KEYS.EMPLOYEES);
            resolve(employees);
        }, 100);
    });
}

async function addEmployee(employeeData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const employees = getStorageData(STORAGE_KEYS.EMPLOYEES);
                const newEmployee = {
                    id: parseInt(generateId()),
                    name: employeeData.name,
                    position: employeeData.position,
                    monthly_salary: employeeData.monthly_salary || 3000
                };
                employees.push(newEmployee);
                
                if (setStorageData(STORAGE_KEYS.EMPLOYEES, employees)) {
                    resolve({ success: true, employee: newEmployee });
                } else {
                    reject(new Error('保存员工数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

async function updateEmployee(employeeId, updateData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const employees = getStorageData(STORAGE_KEYS.EMPLOYEES);
                const index = employees.findIndex(emp => emp.id == employeeId);
                
                if (index === -1) {
                    reject(new Error('员工不存在'));
                    return;
                }
                
                employees[index] = { ...employees[index], ...updateData };
                
                if (setStorageData(STORAGE_KEYS.EMPLOYEES, employees)) {
                    resolve(employees[index]);
                } else {
                    reject(new Error('更新员工数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

async function deleteEmployee(employeeId) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                // 1. 删除基本员工信息
                const employees = getStorageData(STORAGE_KEYS.EMPLOYEES);
                const filteredEmployees = employees.filter(emp => emp.id != employeeId);
                
                // 2. 从考勤员工列表中删除
                const attendanceEmployees = getStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES);
                const filteredAttendanceEmployees = attendanceEmployees.filter(emp => emp.id != employeeId);
                
                // 3. 删除该员工的所有考勤记录
                const attendance = getStorageData(STORAGE_KEYS.ATTENDANCE);
                const filteredAttendance = attendance.filter(record => record.employee_id != employeeId);
                
                // 4. 删除该员工的所有顶班记录（作为被顶班者和顶班者）
                const substitutes = getStorageData(STORAGE_KEYS.SUBSTITUTES);
                const filteredSubstitutes = substitutes.filter(record => 
                    record.employee_id != employeeId && record.substitute_id != employeeId
                );
                
                // 5. 删除该员工的所有项目记录
                const projects = getStorageData(STORAGE_KEYS.PROJECTS);
                const filteredProjects = projects.filter(record => record.employee_id != employeeId);
                
                // 保存所有更新后的数据
                const saveResults = [
                    setStorageData(STORAGE_KEYS.EMPLOYEES, filteredEmployees),
                    setStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES, filteredAttendanceEmployees),
                    setStorageData(STORAGE_KEYS.ATTENDANCE, filteredAttendance),
                    setStorageData(STORAGE_KEYS.SUBSTITUTES, filteredSubstitutes),
                    setStorageData(STORAGE_KEYS.PROJECTS, filteredProjects)
                ];
                
                // 检查是否所有保存操作都成功
                if (saveResults.every(result => result === true)) {
                    resolve({ 
                        success: true, 
                        message: '员工及其所有相关数据已删除',
                        deletedRecords: {
                            attendance: attendance.length - filteredAttendance.length,
                            substitutes: substitutes.length - filteredSubstitutes.length,
                            projects: projects.length - filteredProjects.length
                        }
                    });
                } else {
                    reject(new Error('删除员工数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

// 考勤员工管理API
async function fetchAttendanceEmployees() {
    return new Promise((resolve) => {
        setTimeout(() => {
            const attendanceEmployees = getStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES);
            resolve(attendanceEmployees);
        }, 100);
    });
}

async function addAttendanceEmployeeAPI(employeeId) {
    return new Promise((resolve, reject) => {
        setTimeout(async () => {
            try {
                // 获取员工信息
                const employees = await fetchEmployees();
                const employee = employees.find(emp => emp.id == employeeId);
                
                if (!employee) {
                    reject(new Error('员工不存在'));
                    return;
                }
                
                // 获取考勤员工列表
                const attendanceEmployees = getStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES);
                
                // 检查是否已存在
                const exists = attendanceEmployees.find(emp => emp.id == employeeId);
                if (exists) {
                    reject(new Error('该员工已在考勤管理中'));
                    return;
                }
                
                // 添加到考勤员工列表
                const attendanceEmployee = {
                    id: employee.id,
                    name: employee.name,
                    position: employee.position,
                    monthly_salary: employee.monthly_salary
                };
                
                attendanceEmployees.push(attendanceEmployee);
                
                if (setStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES, attendanceEmployees)) {
                    resolve({ success: true, employee: attendanceEmployee });
                } else {
                    reject(new Error('保存考勤员工数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

async function deleteAttendanceEmployeeAPI(employeeId) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const attendanceEmployees = getStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES);
                const filteredEmployees = attendanceEmployees.filter(emp => emp.id != employeeId);
                
                if (setStorageData(STORAGE_KEYS.ATTENDANCE_EMPLOYEES, filteredEmployees)) {
                    resolve({ success: true });
                } else {
                    reject(new Error('删除考勤员工数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

// 考勤管理API
async function fetchAttendance(params) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allAttendance = getStorageData(STORAGE_KEYS.ATTENDANCE);
            let filteredAttendance = allAttendance;
            
            if (params.year && params.month) {
                const yearMonth = `${params.year}-${params.month.toString().padStart(2, '0')}`;
                filteredAttendance = allAttendance.filter(record => 
                    record.date.startsWith(yearMonth)
                );
            }
            
            resolve(filteredAttendance);
        }, 100);
    });
}

async function addOrUpdateAttendance(attendanceData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const attendance = getStorageData(STORAGE_KEYS.ATTENDANCE);
                const key = `${attendanceData.employee_id}-${attendanceData.date}`;
                
                // 查找现有记录
                const existingIndex = attendance.findIndex(record => 
                    record.employee_id == attendanceData.employee_id && 
                    record.date === attendanceData.date
                );
                
                const record = {
                    employee_id: parseInt(attendanceData.employee_id),
                    date: attendanceData.date,
                    status: attendanceData.status,
                    work_hours: getDefaultWorkHours(attendanceData.status),
                    overtime_hours: 0,
                    notes: attendanceData.notes || ''
                };
                
                if (existingIndex >= 0) {
                    // 更新现有记录
                    attendance[existingIndex] = record;
                } else {
                    // 添加新记录
                    attendance.push(record);
                }
                
                if (setStorageData(STORAGE_KEYS.ATTENDANCE, attendance)) {
                    resolve(record);
                } else {
                    reject(new Error('保存考勤数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

// 顶班管理API
async function fetchSubstitutes(params) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allSubstitutes = getStorageData(STORAGE_KEYS.SUBSTITUTES);
            let filteredSubstitutes = allSubstitutes;
            
            if (params.year && params.month) {
                const yearMonth = `${params.year}-${params.month.toString().padStart(2, '0')}`;
                filteredSubstitutes = allSubstitutes.filter(record => 
                    record.date.startsWith(yearMonth)
                );
            }
            
            resolve(filteredSubstitutes);
        }, 100);
    });
}

async function addOrUpdateSubstitute(substituteData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const substitutes = getStorageData(STORAGE_KEYS.SUBSTITUTES);
                
                // 查找现有记录
                const existingIndex = substitutes.findIndex(record => 
                    record.employee_id == substituteData.employee_id && 
                    record.date === substituteData.date
                );
                
                const record = {
                    employee_id: parseInt(substituteData.employee_id),
                    date: substituteData.date,
                    substitute_id: parseInt(substituteData.substitute_id),
                    substitute_name: substituteData.substitute_name,
                    substitute_status: substituteData.substitute_status
                };
                
                if (existingIndex >= 0) {
                    // 更新现有记录
                    substitutes[existingIndex] = record;
                } else {
                    // 添加新记录
                    substitutes.push(record);
                }
                
                if (setStorageData(STORAGE_KEYS.SUBSTITUTES, substitutes)) {
                    resolve(record);
                } else {
                    reject(new Error('保存顶班数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

async function deleteSubstitute(employeeId, date) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const substitutes = getStorageData(STORAGE_KEYS.SUBSTITUTES);
                const filteredSubstitutes = substitutes.filter(record => 
                    !(record.employee_id == employeeId && record.date === date)
                );
                
                if (setStorageData(STORAGE_KEYS.SUBSTITUTES, filteredSubstitutes)) {
                    resolve({ success: true });
                } else {
                    reject(new Error('删除顶班数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

// 项目管理API
async function fetchProjects(params) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allProjects = getStorageData(STORAGE_KEYS.PROJECTS);
            let filteredProjects = allProjects;
            
            if (params && params.year && params.month) {
                const yearMonth = `${params.year}-${params.month.toString().padStart(2, '0')}`;
                filteredProjects = allProjects.filter(project => 
                    project.date.startsWith(yearMonth)
                );
            }
            
            resolve(filteredProjects);
        }, 100);
    });
}

async function addProject(projectData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const projects = getStorageData(STORAGE_KEYS.PROJECTS);
                const currentDate = new Date();
                const dateString = currentDate.toISOString();
                
                const newProject = {
                    id: parseInt(generateId()),
                    type: projectData.type,
                    monthly_salary: parseFloat(projectData.monthly_salary),
                    daily_salary: parseFloat(projectData.daily_salary),
                    days: parseFloat(projectData.days),
                    total_amount: parseFloat(projectData.daily_salary) * parseFloat(projectData.days),
                    application: projectData.application,
                    personnel: projectData.personnel,
                    date: dateString ? dateString.split('T')[0] : currentDate.toLocaleDateString('sv-SE'), // 当前日期
                    created_at: dateString || currentDate.toISOString()
                };
                
                projects.push(newProject);
                
                if (setStorageData(STORAGE_KEYS.PROJECTS, projects)) {
                    resolve({ success: true, project: newProject });
                } else {
                    reject(new Error('保存项目数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

async function updateProject(projectId, updateData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const projects = getStorageData(STORAGE_KEYS.PROJECTS);
                const index = projects.findIndex(project => project.id == projectId);
                
                if (index === -1) {
                    reject(new Error('项目不存在'));
                    return;
                }
                
                // 更新项目数据
                const currentDate = new Date();
                const dateString = currentDate.toISOString();
                
                const updatedProject = {
                    ...projects[index],
                    type: updateData.type,
                    monthly_salary: parseFloat(updateData.monthly_salary),
                    daily_salary: parseFloat(updateData.daily_salary),
                    days: parseFloat(updateData.days),
                    total_amount: parseFloat(updateData.daily_salary) * parseFloat(updateData.days),
                    application: updateData.application,
                    personnel: updateData.personnel,
                    updated_at: dateString || currentDate.toISOString()
                };
                
                projects[index] = updatedProject;
                
                if (setStorageData(STORAGE_KEYS.PROJECTS, projects)) {
                    resolve({ success: true, project: updatedProject });
                } else {
                    reject(new Error('更新项目数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

async function deleteProject(projectId) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const projects = getStorageData(STORAGE_KEYS.PROJECTS);
                const filteredProjects = projects.filter(project => project.id != projectId);
                
                if (setStorageData(STORAGE_KEYS.PROJECTS, filteredProjects)) {
                    resolve({ success: true });
                } else {
                    reject(new Error('删除项目数据失败'));
                }
            } catch (error) {
                reject(error);
            }
        }, 100);
    });
}

// 获取考勤汇总数据（用于项目管理）
async function fetchAttendanceSummary(year, month) {
    return new Promise(async (resolve) => {
        setTimeout(async () => {
            const employees = await fetchEmployees();
            const attendance = await fetchAttendance({ year, month });
            const substitutes = await fetchSubstitutes({ year, month });
            
            // 构建员工汇总数据
            const summary = employees.map(employee => ({
                employee_id: employee.id,
                employee_name: employee.name,
                position: employee.position,
                monthly_salary: employee.monthly_salary || 3000
            }));
            
            resolve(summary);
        }, 100);
    });
}

// 工具函数：根据状态获取默认工作小时
function getDefaultWorkHours(status) {
    switch(status) {
        case '全': return 8;
        case '上': return 4;
        case '下': return 4;
        case '休': return 0;
        case '假': return 0;
        default: return 8;
    }
}

// 消息提示函数
function showSuccessMessage(message) {
    showMessage(message, 'success');
}

function showErrorMessage(message) {
    showMessage(message, 'danger');
}

function showMessage(message, type = 'info') {
    // 创建提示框
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // 3秒后自动消失
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 3000);
}

// 页面加载时初始化默认数据
document.addEventListener('DOMContentLoaded', function() {
    initializeDefaultData();
});

console.log('本地存储API已加载');
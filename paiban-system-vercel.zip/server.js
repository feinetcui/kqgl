const express = require('express');
const path = require('path');
const app = express();

// 静态文件服务
app.use(express.static(path.join(__dirname, 'public')));

// 中间件
app.use(express.json());
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// 简单的内存存储
var employees = [
  { id: '1', name: '李玉琴', position: '大堂经理', monthly_salary: 3200 },
  { id: '2', name: '张海霞', position: '大堂经理', monthly_salary: 3100 },
  { id: '3', name: '郑林娟', position: '大堂经理', monthly_salary: 3150 }
];

var nextId = 4;

// 健康检查接口
app.get('/api/health', function(req, res) {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    message: '排班系统 API 正常运行',
    version: '4.0.0'
  });
});

// 获取所有员工
app.get('/api/employees', function(req, res) {
  console.log('获取员工列表请求');
  res.json(employees);
});

// 添加员工
app.post('/api/employees', function(req, res) {
  var name = req.body.name;
  var position = req.body.position;
  var monthly_salary = req.body.monthly_salary;
  
  console.log('添加员工请求:', { name: name, position: position, monthly_salary: monthly_salary });
  
  if (!name || !position) {
    return res.status(400).json({ error: '姓名和岗位不能为空' });
  }
  
  // 检查姓名是否已存在
  var existingEmployee = null;
  for (var i = 0; i < employees.length; i++) {
    if (employees[i].name === name) {
      existingEmployee = employees[i];
      break;
    }
  }
  
  if (existingEmployee) {
    return res.status(400).json({ error: '该姓名的员工已存在' });
  }
  
  // 添加新员工
  var newEmployee = {
    id: String(nextId++),
    name: name,
    position: position,
    monthly_salary: monthly_salary || 3000
  };
  
  employees.push(newEmployee);
  
  console.log('员工添加成功:', newEmployee);
  res.json({ id: newEmployee.id });
});

// 更新员工
app.put('/api/employees/:id', function(req, res) {
  var employeeId = req.params.id;
  var name = req.body.name;
  var position = req.body.position;
  var monthly_salary = req.body.monthly_salary;
  
  var employeeIndex = -1;
  for (var i = 0; i < employees.length; i++) {
    if (employees[i].id === employeeId) {
      employeeIndex = i;
      break;
    }
  }
  
  if (employeeIndex === -1) {
    return res.status(404).json({ error: '员工不存在' });
  }
  
  // 检查是否为部分更新（只更新月工资）
  var providedFields = Object.keys(req.body);
  var isPartialUpdate = providedFields.length === 1 && 
                        providedFields[0] === 'monthly_salary' && 
                        req.body.monthly_salary !== undefined;
  
  if (isPartialUpdate) {
    employees[employeeIndex].monthly_salary = monthly_salary;
  } else {
    if (!name || !position || monthly_salary === undefined) {
      return res.status(400).json({ 
        error: '完整更新需要提供有效的姓名、岗位和月工资'
      });
    }
    
    employees[employeeIndex].name = name;
    employees[employeeIndex].position = position;
    employees[employeeIndex].monthly_salary = monthly_salary;
  }
  
  res.json({ changes: 1 });
});

// 删除员工
app.delete('/api/employees/:id', function(req, res) {
  var employeeId = req.params.id;
  var employeeIndex = -1;
  
  for (var i = 0; i < employees.length; i++) {
    if (employees[i].id === employeeId) {
      employeeIndex = i;
      break;
    }
  }
  
  if (employeeIndex === -1) {
    return res.status(404).json({ error: '员工不存在' });
  }
  
  employees.splice(employeeIndex, 1);
  res.json({ changes: 1 });
});

// 其他简化的 API
app.get('/api/attendance', function(req, res) {
  res.json([]);
});

app.post('/api/attendance', function(req, res) {
  res.json({ id: '1' });
});

app.get('/api/substitutes', function(req, res) {
  res.json([]);
});

app.post('/api/substitutes', function(req, res) {
  res.json({ id: '1' });
});

app.get('/api/attendance/summary/:year/:month', function(req, res) {
  res.json([]);
});

app.post('/api/employees/cleanup', function(req, res) {
  res.json({ message: '清理完成', deletedCount: 0 });
});

// 错误处理
app.use(function(err, req, res, next) {
  console.error('服务器错误:', err);
  res.status(500).json({ error: '服务器内部错误' });
});

var PORT = process.env.PORT || 3000;

app.listen(PORT, function() {
  console.log('服务器运行在端口 ' + PORT);
  console.log('使用兼容的 Express 版本');
});